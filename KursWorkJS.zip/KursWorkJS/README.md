# KursWorkJS

Authors - ASRAGOD (vlad jaschuk), Illia 
